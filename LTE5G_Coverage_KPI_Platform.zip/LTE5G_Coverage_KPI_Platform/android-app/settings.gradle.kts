rootProject.name = "CoverageKPI"
include(":app")
