package com.example.coverage

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.CellInfo
import android.telephony.CellSignalStrength
import android.telephony.TelephonyManager
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import android.widget.Button
import android.widget.TextView
import kotlinx.coroutines.*
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

class MainActivity : ComponentActivity() {
    private lateinit var telephony: TelephonyManager
    private lateinit var tv: TextView
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
            // No-op; user action handled implicitly
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.tvStatus)
        telephony = getSystemService(TelephonyManager::class.java)

        findViewById<Button>(R.id.btnCollectOnce).setOnClickListener { collectAndShow() }
        findViewById<Button>(R.id.btnStart).setOnClickListener { /* stub for periodic worker */ }
        findViewById<Button>(R.id.btnStop).setOnClickListener { /* stub */ }

        ensurePerms()
    }

    private fun ensurePerms() {
        val perms = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        requestPermissionLauncher.launch(perms)
    }

    private fun collectAndShow() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            tv.text = "Grant location/phone permissions first."
            return
        }
        val cells: List<CellInfo>? = telephony.allCellInfo
        val msg = StringBuilder("Cells: \n")
        cells?.take(5)?.forEach { c ->
            val s: CellSignalStrength? = when {
                c is android.telephony.CellInfoLte -> c.cellSignalStrength
                c is android.telephony.CellInfoNr -> c.cellSignalStrength
                else -> null
            }
            msg.append(s?.toString() ?: "unknown").append("\n")
        }
        tv.text = msg.toString()
    }
}
