# LTE/5G Coverage & KPI Testing Platform

This project contains:
1. **Android app** (Kotlin) for collecting basic LTE/5G radio KPIs using `TelephonyManager` and buttons to trigger sample collection.
2. **Cloud backend** (FastAPI + SQLite) to ingest and query KPI measurements via REST with an `X-API-Key` header.

> Note: Low-level radio KPIs vary by device/vendor. For advanced metrics (QXDM, vendor SDKs), integrate in `MainActivity` or a foreground `Service`.

## Setup

### Backend
See `backend/README.md` for full steps. Quick run:
```bash
cd backend
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
./run.sh
```

### Android
Open `android-app/` in Android Studio (Giraffe+). Build & run on a physical device for radio info.
Set the backend URL and API key in your Retrofit client (stub included).

## API
- `POST /measurements/` with radio/location/KPI JSON payload
- `GET /measurements/?tech=LTE&limit=50`

## Security
- Basic API key auth header. For production, add OAuth2/JWT and TLS.
