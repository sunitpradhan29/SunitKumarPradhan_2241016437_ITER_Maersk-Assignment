# LTE/5G Coverage & KPI Backend (FastAPI + SQLite)

## Quickstart
```bash
cd backend
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # change API_KEY if needed
./run.sh
```

- API: `http://localhost:8080`
- Auth: add header `X-API-Key: <your-key>`

## Endpoints
- `POST /measurements/` – Ingest a measurement
- `GET /measurements/` – Query recent measurements

## Data Model
See `app/models.py` for all fields (RSRP, RSRQ, SINR, throughput, latency, lat/lon, etc.).
