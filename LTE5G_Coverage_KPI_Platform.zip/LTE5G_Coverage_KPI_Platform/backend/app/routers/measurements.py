from fastapi import APIRouter, Depends, HTTPException, Header, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from ..database import get_db
from ..models import Measurement
from ..schemas.schemas import MeasurementCreate, MeasurementOut
import os

router = APIRouter(prefix="/measurements", tags=["measurements"])

API_KEY = os.getenv("API_KEY", "changeme-supersecret")

def auth(x_api_key: Optional[str] = Header(None)):
    if x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")

@router.post("/", response_model=MeasurementOut, dependencies=[Depends(auth)])
def create_measurement(payload: MeasurementCreate, db: Session = Depends(get_db)):
    m = Measurement(**payload.dict())
    db.add(m)
    db.commit()
    db.refresh(m)
    return m

@router.get("/", response_model=List[MeasurementOut], dependencies=[Depends(auth)])
def query_measurements(
    db: Session = Depends(get_db),
    tech: Optional[str] = Query(None),
    device_id: Optional[str] = Query(None),
    limit: int = Query(100, le=1000)
):
    q = db.query(Measurement).order_by(Measurement.id.desc())
    if tech:
        q = q.filter(Measurement.tech == tech)
    if device_id:
        q = q.filter(Measurement.device_id == device_id)
    return q.limit(limit).all()
