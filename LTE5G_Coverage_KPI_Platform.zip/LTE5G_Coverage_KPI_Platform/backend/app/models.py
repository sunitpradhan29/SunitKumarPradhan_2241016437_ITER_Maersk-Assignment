from sqlalchemy import Column, Integer, Float, String, DateTime
from sqlalchemy.sql import func
from .database import Base

class Measurement(Base):
    __tablename__ = "measurements"
    id = Column(Integer, primary_key=True, index=True)
    # Radio info
    tech = Column(String, index=True)  # LTE, 5G
    mcc = Column(Integer)
    mnc = Column(Integer)
    tac = Column(Integer)  # or tracking area code
    cell_id = Column(Integer)
    # KPIs
    rsrp = Column(Float)   # Reference Signal Received Power
    rsrq = Column(Float)   # Reference Signal Received Quality
    sinr = Column(Float)   # Signal to Interference plus Noise Ratio
    rssi = Column(Float)   # Received Signal Strength Indicator
    dl_throughput_mbps = Column(Float)
    ul_throughput_mbps = Column(Float)
    latency_ms = Column(Float)
    # Location
    lat = Column(Float, index=True)
    lon = Column(Float, index=True)
    # Device & time
    device_id = Column(String, index=True)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), index=True)
