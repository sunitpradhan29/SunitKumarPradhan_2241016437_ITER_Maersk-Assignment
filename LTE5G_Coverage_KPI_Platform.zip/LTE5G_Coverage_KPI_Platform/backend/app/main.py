from fastapi import FastAPI
from .database import Base, engine
from .routers import measurements

app = FastAPI(title="LTE/5G Coverage & KPI Backend")
Base.metadata.create_all(bind=engine)

app.include_router(measurements.router)

@app.get("/")
def root():
    return {"status": "ok", "service": "coverage-backend"}
