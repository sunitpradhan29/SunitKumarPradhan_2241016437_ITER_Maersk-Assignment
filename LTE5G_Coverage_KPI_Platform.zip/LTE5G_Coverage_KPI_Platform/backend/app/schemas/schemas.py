from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime

class MeasurementCreate(BaseModel):
    tech: str = Field(examples=["LTE", "5G"])
    mcc: int
    mnc: int
    tac: int
    cell_id: int
    rsrp: float
    rsrq: float
    sinr: float
    rssi: float
    dl_throughput_mbps: float
    ul_throughput_mbps: float
    latency_ms: float
    lat: float
    lon: float
    device_id: str

class MeasurementOut(MeasurementCreate):
    id: int
    timestamp: datetime

    class Config:
        from_attributes = True
