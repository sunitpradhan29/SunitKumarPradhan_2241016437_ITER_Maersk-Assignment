#!/usr/bin/env bash
set -euo pipefail
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with SMTP + recipients before running
uvicorn service.main:app --host 0.0.0.0 --port 8090 --reload
