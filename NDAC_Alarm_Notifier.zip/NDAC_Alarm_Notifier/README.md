# Backend Service for NDAC Alarm Email Notifications

Monitors NDAC alarms (via API or log file) and emails stakeholders for **CRITICAL** and **MAJOR** alarms.
Also hosts a minimal dashboard at `/` to show the last emailed table.

## Quickstart
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set SMTP_* and RECIPIENTS in .env
uvicorn service.main:app --host 0.0.0.0 --port 8090 --reload
```

- Scheduler interval configurable via `SCAN_INTERVAL_MINUTES` in `.env` (default 60).
- Replace `ndac_client.fetch_alarms()` with actual NDAC REST calls as needed.

## Email Content
- Includes severity, type, affected element, timestamp, and details.
- Template located in `service/notifier.py`.

## Optional Enhancements
- Add persistence (SQLite/Postgres) for alarm history.
- Add authentication to the dashboard.
- Add retry logic and dead-letter queue for failed emails.
