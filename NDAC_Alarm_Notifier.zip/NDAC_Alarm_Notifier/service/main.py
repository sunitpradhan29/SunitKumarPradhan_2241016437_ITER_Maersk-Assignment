import os
from dotenv import load_dotenv
from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from typing import List
from ndac_client import fetch_alarms
from notifier import filter_and_render
from email_util import send_email

load_dotenv()

RECIPIENTS = [r.strip() for r in os.getenv("RECIPIENTS", "").split(",") if r.strip()]
INTERVAL_MINUTES = int(os.getenv("SCAN_INTERVAL_MINUTES", "60"))

app = FastAPI(title="NDAC Alarm Email Service")
scheduler = BackgroundScheduler()
last_html = ""

def job():
    global last_html
    alarms = fetch_alarms()
    html = filter_and_render(alarms)
    if html:
        send_email("NDAC Alarm Alert", html, RECIPIENTS)
        last_html = html

@app.on_event("startup")
def on_start():
    scheduler.add_job(job, "interval", minutes=INTERVAL_MINUTES, id="scan")
    scheduler.start()

@app.on_event("shutdown")
def on_shutdown():
    scheduler.shutdown(wait=False)

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return last_html or "<p>No CRITICAL/MAJOR alarms yet.</p>"
