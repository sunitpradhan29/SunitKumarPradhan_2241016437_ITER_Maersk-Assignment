from typing import List, Dict
from jinja2 import Template

SEVERITY_RANK = {"CRITICAL": 3, "MAJOR": 2, "MINOR": 1, "INFO": 0}

TEMPLATE = Template('''
<h3>NDAC Alarm Notification</h3>
<p>The following alarms were detected:</p>
<table border="1" cellpadding="6" cellspacing="0">
<tr><th>Severity</th><th>Type</th><th>Element</th><th>Timestamp</th><th>Detail</th></tr>
{% for a in alarms %}
<tr>
  <td>{{ a.severity }}</td>
  <td>{{ a.type }}</td>
  <td>{{ a.element }}</td>
  <td>{{ a.timestamp }}</td>
  <td>{{ a.detail }}</td>
</tr>
{% endfor %}
</table>
''')

def filter_and_render(alarms: List[Dict]) -> str:
    # Keep only CRITICAL and MAJOR
    filtered = [a for a in alarms if SEVERITY_RANK.get(a.get("severity", ""), 0) >= 2]
    if not filtered:
        return ""
    filtered.sort(key=lambda x: SEVERITY_RANK.get(x.get("severity", ""), 0), reverse=True)
    return TEMPLATE.render(alarms=filtered)
