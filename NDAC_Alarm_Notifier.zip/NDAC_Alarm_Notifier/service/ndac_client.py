import os, json, time
from typing import List, Dict, Any
from datetime import datetime, timezone

# In production, replace with requests to NDAC REST API using NDAC_API_BASE and NDAC_API_TOKEN.
def fetch_alarms() -> List[Dict[str, Any]]:
    log_path = os.getenv("NDAC_LOG_PATH", "./sample_ndac_log.json")
    if not os.path.exists(log_path):
        return []
    with open(log_path, "r") as f:
        data = json.load(f)
    # normalize timestamp
    for a in data:
        if isinstance(a.get("timestamp"), str):
            a["timestamp"] = a["timestamp"]
        else:
            a["timestamp"] = datetime.now(timezone.utc).isoformat()
    return data
